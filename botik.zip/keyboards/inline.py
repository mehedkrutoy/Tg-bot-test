from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def get_start_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Пополнить", callback_data="replenish"),
            InlineKeyboardButton(text="Вывод", callback_data="withdraw")
        ],
        [
            InlineKeyboardButton(text="Профиль", callback_data="profile"),
            InlineKeyboardButton(text="Курс", callback_data="course")
        ],
        [
            InlineKeyboardButton(text="Новостник", callback_data="news"),
            InlineKeyboardButton(text="Отзывы", callback_data="reviews"),
            InlineKeyboardButton(text="Поддержка", callback_data="support")
        ],
        [
            InlineKeyboardButton(text="Калькулятор", callback_data="calculator")
        ]
    ])

def get_payment_methods_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Оплата картой", callback_data="card_payment")
        ],
        [
            InlineKeyboardButton(text="Назад в меню", callback_data="main_menu")
        ]
    ])

def get_profile_keyboard(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Активировать промокод", callback_data="activate_promo")
        ],
        [
            InlineKeyboardButton(text="Назад в меню", callback_data="main_menu")
        ]
    ])

def get_support_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Связаться с поддержкой", callback_data="start_support")
        ],
        [
            InlineKeyboardButton(text="Назад в меню", callback_data="main_menu")
        ]
    ]) 