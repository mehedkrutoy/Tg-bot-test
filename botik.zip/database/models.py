from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, unique=True)
    username = Column(String)
    balance = Column(Float(precision=2), default=0.0)
    referrer_id = Column(Integer, nullable=True)
    total_referrals = Column(Integer, default=0)
    registered_at = Column(DateTime, default=datetime.utcnow)

class Payment(Base):
    __tablename__ = 'payments'

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.user_id'))
    amount = Column(Float)
    status = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class PromoCode(Base):
    __tablename__ = 'promo_codes'

    code = Column(String, primary_key=True)
    amount = Column(Float)
    uses_left = Column(Integer)
    is_percentage = Column(Integer, default=0)

class UsedPromoCode(Base):
    __tablename__ = 'used_promo_codes'

    user_id = Column(Integer, ForeignKey('users.user_id'), primary_key=True)
    code = Column(String, ForeignKey('promo_codes.code'), primary_key=True) 