from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .models import Base, User, Payment, PromoCode, UsedPromoCode
from typing import Optional, Tuple

engine = create_engine('sqlite:///bot.db')
Session = sessionmaker(bind=engine)

def create_db():
    Base.metadata.create_all(engine)

async def get_user_balance(user_id: int) -> float:
    session = Session()
    try:
        user = session.query(User).filter(User.user_id == user_id).first()
        return float(str(user.balance)) if user else 0.0
    finally:
        session.close()

async def get_user_profile(user_id: int) -> Optional[Tuple[float, int]]:
    session = Session()
    try:
        user = session.query(User).filter(User.user_id == user_id).first()
        if user:
            return float(str(user.balance)), int(str(user.total_referrals))
        return None
    finally:
        session.close()

async def update_balance(user_id: int, amount: float) -> bool:
    session = Session()
    try:
        user = session.query(User).filter(User.user_id == user_id).first()
        if user:
            setattr(user, 'balance', float(str(user.balance)) + amount)
            if str(user.referrer_id) and amount > 0:
                referrer = session.query(User).filter(User.user_id == user.referrer_id).first()
                if referrer:
                    setattr(referrer, 'balance', float(str(referrer.balance)) + amount * 0.05)
            session.commit()
            return True
        return False
    finally:
        session.close()

async def check_promo_code(code: str, user_id: int) -> Optional[dict]:
    session = Session()
    try:
        promo = session.query(PromoCode).filter(PromoCode.code == code).first()
        if not promo or int(str(promo.uses_left)) <= 0:
            return None
            
        used = session.query(UsedPromoCode).filter(
            UsedPromoCode.user_id == user_id,
            UsedPromoCode.code == code
        ).first()
        
        if used:
            return None
            
        return {
            'code': code,
            'amount': promo.amount,
            'is_percentage': bool(promo.is_percentage)
        }
    finally:
        session.close()

async def get_all_users():
    session = Session()
    users = session.query(User).all()
    session.close()
    return users 