from aiogram import Router, F
from aiogram.types import Message, PreCheckoutQuery, CallbackQuery, LabeledPrice
from aiogram.fsm.context import FSMContext
from database.methods import update_balance
from config.config import config
from keyboards.inline import get_start_keyboard

router = Router()

@router.callback_query(F.data == "card_payment")
async def process_card_payment(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
        
    await callback.bot.send_invoice(
        chat_id=callback.message.chat.id,
        title="Пополнение баланса",
        description="Пополнение баланса через платежную систему",
        payload="payment_balance",
        provider_token=config.PAYMENT_TOKEN,
        currency="RUB",
        prices=[
            LabeledPrice(label="Пополнение", amount=5000)
        ]
    )

@router.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)

@router.message(F.successful_payment)
async def process_successful_payment(message: Message, state: FSMContext):
    if not message.successful_payment or not message.from_user:
        return
        
    payment_amount = message.successful_payment.total_amount / 100
    bonus_amount = 0
    
    state_data = await state.get_data()
    active_promo = state_data.get('active_promo')
    
    if active_promo:
        bonus_percent = active_promo['percent']
        bonus_amount = payment_amount * (bonus_percent / 100)
        payment_amount += bonus_amount

    await update_balance(message.from_user.id, payment_amount)
    await state.clear()
    
    success_message = f"✅ Платеж на сумму {payment_amount} RUB успешно выполнен!"
    if active_promo:
        success_message += f"\n💎 Бонус по промокоду: {bonus_amount} RUB"
    
    await message.answer(
        success_message,
        reply_markup=get_start_keyboard()
    ) 