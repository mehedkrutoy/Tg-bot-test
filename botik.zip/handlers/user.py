from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import LabeledPrice
from typing import Union

from keyboards.inline import get_start_keyboard, get_payment_methods_keyboard, get_profile_keyboard
from states.states import Form, ReplenishStates, NumberInput
from database.methods import get_user_balance, get_user_profile
from config.config import config

router = Router()

@router.message(Command("start"))
async def cmd_start(message: Message):
    if not message.from_user or not message.text:
        return
        
    args = message.text.split()
    referrer_id = None
    if len(args) > 1:
        try:
            referrer_id = int(args[1])
        except ValueError:
            pass
            
    sent_message = await message.answer(
        "Добро пожаловать! Выберите действие:",
        reply_markup=get_start_keyboard()
    )

@router.callback_query(F.data == "profile")
async def show_profile(callback: CallbackQuery):
    if not callback.from_user or not callback.message or not callback.bot:
        return
        
    user_data = await get_user_profile(callback.from_user.id)
    if user_data:
        balance, total_referrals = user_data
        ref_link = f"https://t.me/{(await callback.bot.me()).username}?start={callback.from_user.id}"
        
        profile_text = f"""👤 Ваш профиль:
        
💰 Баланс: {balance} RUB
👥 Рефералов: {total_referrals}

🔗 Ваша реферальная ссылка:
{ref_link}

💎 За каждого приглашенного пользователя вы получаете 5% от его пополнений!"""
        
        await callback.bot.edit_message_text(
            text=profile_text,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
            reply_markup=get_profile_keyboard(callback.from_user.id)
        )

@router.callback_query(F.data == "calculator")
async def handle_calculator(callback: CallbackQuery, state: FSMContext):
    if not callback.message or not callback.bot:
        return
        
    await callback.bot.edit_message_text(
        text="Введите число для умножения:",
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id
    )
    await state.set_state(NumberInput.waiting_for_number)

@router.message(NumberInput.waiting_for_number)
async def process_number(message: Message, state: FSMContext):
    if not message.text:
        return
        
    try:
        value = float(message.text.replace(",", "."))
        result = config.COURSE_RATE * value
        await message.answer(
            f"Результат: {result}",
            reply_markup=get_start_keyboard()
        )
        await state.clear()
    except ValueError:
        await message.answer("Пожалуйста, введите корректное число.") 

@router.message(F.text == "Главное меню")
@router.callback_query(F.data == "main_menu")
async def return_to_main_menu(event: Union[Message, CallbackQuery]):
    if isinstance(event, CallbackQuery):
        if not event.message or not event.bot:
            return
        await event.bot.edit_message_text(
            text="Выберите действие:",
            chat_id=event.message.chat.id,
            message_id=event.message.message_id,
            reply_markup=get_start_keyboard()
        )
    else:
        await event.answer(
            "Выберите действие:",
            reply_markup=get_start_keyboard()
        )

@router.callback_query(F.data == "news")
async def show_news(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
    await callback.bot.edit_message_text(
        text=f"Наш новостной канал: {config.GROUP_NEWS}",
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        reply_markup=get_start_keyboard()
    )

@router.callback_query(F.data == "reviews")
async def show_reviews(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
    await callback.bot.edit_message_text(
        text=f"Наши отзывы: {config.GROUP_REVIEWS}",
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        reply_markup=get_start_keyboard()
    )

@router.callback_query(F.data == "course")
async def show_course(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
    await callback.bot.edit_message_text(
        text=f"Текущий курс: {config.COURSE_RATE}",
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        reply_markup=get_start_keyboard()
    )

@router.callback_query(F.data == "withdraw")
async def show_withdraw(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
    await callback.bot.edit_message_text(
        text="Для вывода средств обратитесь в поддержку",
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        reply_markup=get_start_keyboard()
    ) 