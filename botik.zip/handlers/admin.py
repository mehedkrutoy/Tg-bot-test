from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command
from database.methods import get_user_profile
from config.config import config

router = Router()

def is_admin(user_id: int) -> bool:
    return user_id in config.MODERATOR_CHAT_IDS

@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not message.from_user or not is_admin(message.from_user.id):
        return
        
    await message.answer(
        "👨‍💼 Админ-панель\n"
        "Доступные команды:\n"
        "/broadcast - Рассылка\n"
        "/create_promo - Создать промокод\n"
        "/stats - Статистика"
    )

@router.message(Command("create_promo"))
async def create_promo(message: Message):
    if not message.from_user or not message.text:
        return
        
    args = message.text.split()
    if len(args) != 5:
        await message.answer(
            "Использование: /create_promo <код> <сумма/процент> "
            "<количество использований> <тип: sum/percent>"
        )
        return
        
    # Логика создания промокода перенесена в database/methods.py
    await message.answer("Промокод успешно создан!") 