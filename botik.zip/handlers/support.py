from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

from states.states import Form
from config.config import config
from keyboards.reply import get_end_chat_keyboard
from keyboards.inline import get_support_keyboard, get_start_keyboard

router = Router()
support_chats = {}

@router.callback_query(F.data == "support")
async def show_support_info(callback: CallbackQuery):
    if not callback.message or not callback.bot:
        return
        
    support_text = """🧑‍💻 Часто задаваемые вопросы:

1. Почему так долго проверяют чек?
• Чеки проверяются в ручную, а не автоматически. До 24 часов занимает проверка чека.

2. Почему так долго выводят золото?
• Вывод золота занимает до 24 часов. Мы стараемся как можно быстрее вывести вам золото.

3. Безопасно ли у вас покупать?
• Вес�� товар получен честным путём. Если сомневаетесь в безопасности, лучше покупать в игре.

💡 Прежде чем задать вопрос, убедитесь что здесь нет ответа на ваш вопрос

Связаться - @pr1nce82"""

    await callback.bot.edit_message_text(
        text=support_text,
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        reply_markup=get_support_keyboard()
    )

@router.callback_query(F.data == "start_support")
async def start_support_chat(callback: CallbackQuery, state: FSMContext):
    if not callback.from_user or not callback.message:
        return
        
    user_id = callback.from_user.id
    
    if user_id in config.MODERATOR_CHAT_IDS:
        await callback.message.answer("Вы модератор и не можете создать запрос в поддержку")
        return
        
    if user_id in support_chats:
        await callback.message.answer("У вас уже есть активный чат с поддержкой")
        return
        
    support_chats[user_id] = {
        "user_id": user_id,
        "username": callback.from_user.username or "Неизвестный пользов��тель"
    }
    
    await state.set_state(Form.in_support_chat)
    await callback.message.answer(
        "Чат с поддержкой создан. Отправьте ваше сообщение.",
        reply_markup=get_end_chat_keyboard()
    )

@router.message(Form.in_support_chat)
async def handle_support_message(message: Message, state: FSMContext):
    if not message.from_user or not message.text or not message.bot:
        return
        
    user_id = message.from_user.id
    
    if message.text == "Завершить чат":
        await end_support_chat(user_id, state)
        await message.answer(
            "Чат с поддержкой завершен",
            reply_markup=get_start_keyboard()
        )
        return

    # Пересылка сообщения модераторам
    for moderator_id in config.MODERATOR_CHAT_IDS:
        await message.bot.send_message(
            moderator_id,
            f"Сообщение от {message.from_user.username or 'Неизвестный'}\n"
            f"ID: {user_id}\n\n"
            f"Текст: {message.text}"
        )

async def end_support_chat(user_id: int, state: FSMContext):
    if user_id in support_chats:
        del support_chats[user_id]
    await state.clear() 